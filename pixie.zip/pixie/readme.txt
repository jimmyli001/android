****************************************************************************
*  Pixie Version 4.1
*  Nattyware
*  http://www.nattyware.com
****************************************************************************
							Updated Sep 21, 2009


  WHAT IS PIXIE
  =============

  Pixie is a color picker made for Web designers, graphic artists and 
  anybody who works with images and colors. 


  SYSTEM REQUIREMENTS
  ===================

  Microsoft Windows 2000, Microsoft Windows XP Home/Pro, Microsoft 
  Windows Vista


  INSTALLATION
  ============

  This is a portable edition of Pixie. It does not require installation.
  Simply copy the executable file to any convenient location and run it
  directly from there. 


  ONLINE RESOURCES
  ================

  For more information about Pixie please refer to the online help at 
  http://www.nattyware.com/help/pixie.php

  For technical support and assistance please contact us at 
  http://www.nattyware.com/support.php


  STAY INFORMED
  =============

  * Follow us on Twitter at http://twitter.com/nattyware
  * Subscribe to the RSS feed at http://feeds2.feedburner.com/nattyware

